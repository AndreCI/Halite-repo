/**
 * Created by andre on 15/11/2016.
 */
public class BiTuple<X, Y> {
    public final X decay;
    public final Y direction;
    public BiTuple(X decay, Y direction) {
        this.decay = decay;
        this.direction = direction;
    }
}
