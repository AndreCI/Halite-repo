public class Site {
    public int owner, strength, production;
}
